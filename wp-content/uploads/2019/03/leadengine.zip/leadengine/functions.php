<?php
/**
 * leadengine functions file
 *
 * @package leadengine
 * by KeyDesign
 */

require_once( get_template_directory() . '/core/init.php');

 // -------------------------------------
 // Edit below this line
 // -------------------------------------

